
#tuple
t=(1,3,9.6,'dharsh')
print(t)
#type
t=(1)
print(type(t))

t=(1,)
print(type(t))
#collection set
s={1,3,4,4,6,7,6,8}
print(s)
#adding a value
s={1,3,4,4,6,7,6,8}
s.add(2)
print(s)

s={1,3,4,4,6,7,6,8}
s1={'a','b','c'}
print(s1)

#remove
s={1,3,4,4,6,7,6,8}
s1={'a','b','c'}
s.remove(6)
print(s)

#add and remove   (unordered due to presence of string)
s={1,3,4,4,6,7,6,8}
s.add("dharsh")
s.remove(3)
print(s)

#discard
s={1,3,4,4,6,7,6,8}
s.discard(4)
print(s)

#union
s1={1,3,4,7,9,9}
s2={'a','d','k','b'}
s3=s1.union(s2)
print

#update
s1={1,3,4,7,9,9}
s2={'a','d','k','b'}
s1.update(s2)
print(s1)

#intersection
s1={1,3,4,7,9,9}
s2={'a','d','k','b',1,3,9}
s=s1.intersection(s2)
print(s)