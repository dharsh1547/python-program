d={"abc":2,"xyz":3,"cse":4,"pqr":5,"asw":4}
print(d["asw"])