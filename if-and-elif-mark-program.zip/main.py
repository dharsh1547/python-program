n=int(input("enter your mark="))
if n>35 and n<70:
    print("pass")
    print("need more improvement")
elif n>70:
    print("passed... Good perform!")
else:  
    print("fail")