'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
#list
l=[15,33,'hello','dharsh']
l.insert(3,'hey')
print(l)
#pop
l=[15,33,'hello','dharsh']
l.insert(3,'hey')
l.pop(4)
print(l)
#sort    ascending order
l=[5,44,63,99,54]
l.sort()
print(l)
#reverse
l=[5,44,63,99,54]
l.reverse()
print(l)





