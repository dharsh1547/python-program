'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
#methods 
name="dharshini"
a= name.upper()
print(a)

name="DHARSHINI"
a=name.lower()
print(a)

name="dharshini"
a=name.isupper()
print(a)

name="dharshini"
a=name.islower()
print(a)

name="dharshini"
print(name[0:8:3])

name="Dharshini"
a=name.capitalize()
print(a)

