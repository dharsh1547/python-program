num=int(input("enter a number:"))
if (num%7==0):
    print("it is a multiple of 7")
else:
    print("it is not a multiple of 7")
